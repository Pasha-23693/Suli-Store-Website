<?php
$db = mysqli_connect("localhost","root","","suli_store");

functoin getpro(){

global $db;

}
 ?>
