<div class="panel panel-default sidebar-menu"><!--panel panel-default sidebar-menu begin-->
  <div class="panel-heading"><!--panel-heading begin-->
    <center><!--center begin-->
      <img src="customer_images/MarkZuckerberg.jpg" alt="logo">
    </center><!--center finish-->
    <br/>
    <h3 class="panel-title" align="center"><!--panel-title begin-->

      Name:Pasha Jaff
    </h3><!--panel-title finish-->
  </div><!--panel-heading finish-->
  <div class="panel-body"><!--panel-body begin-->
    <ul class="nav-pills nav-stacked nav"><!--nav-pills nav-stacked-nav begin-->
      <li class="<?php if(isset($_GET['my_orders'])){echo"active";}?>">
        <a href="my_account.php?my_orders">
          <i class="glyphicon glyphicon-list"> My Orders </i>
        </a>
      </li>


      <li class="<?php if(isset($_GET['pay_offline'])){echo"active";}?>">
        <a href="my_account.php?pay_offline">
          <i class="fa fa-bolt">   Pay offline </i>
        </a>
      </li>
      <li class="<?php if(isset($_GET['edit_account'])){echo"active";}?>">
        <a href="my_account.php?edit_account">
          <i class="glyphicon glyphicon-pencil"> Edit Account </i>
        </a>
      </li>


      <li class="<?php if(isset($_GET['change_pass'])){echo"active";}?>">
        <a href="my_account.php?change_pass">
          <i class="fa fa-user">   change password </i>
        </a>
      </li>

      <li class="<?php if(isset($_GET['delete_account'])){echo"active";}?>">
        <a href="my_account.php?delete_account">
          <i class="fa fa-trash-o"> Delete Account </i>
        </a>
      </li>


      <li >
        <a href="logout.php">
          <i class="fa fa-sign-out">   Log out </i>
        </a>
      </li>
    </ul><!--nav-pills nav-stacked-nav finish-->
  </div><!--panel-body finish-->
</div><!--panel panel-default sidebar-menu finish-->
