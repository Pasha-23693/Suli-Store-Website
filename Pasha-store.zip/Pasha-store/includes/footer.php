<div id="footer"><!-- FOOTER begin -->
  <div class="container"><!-- containerR begin -->
    <div class="row"><!-- row begin -->
      <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 begin -->

        <h4> Pages </h4>

      <ul><!-- ul begin -->
        <li><a href="Cart.php">Shopping Cart</a></li>
        <li><a href="cantact.php">Contact Us</a></li>
        <li><a href="shop.php">Shop</a></li>
        <li><a href="my_account.php">My Account</a></li>
      </ul><!-- ul finish -->

        <hr>

         <h4> User Section </h4>

         <ul><!-- ul begin -->
           <li><a href="my_account.php">Loging</a></li>
           <li><a href="Customer_ragister.php">Register</a></li>
         </ul><!-- ul finish -->

         <hr class="hidden-md hidden-lg hidden-sm">

      </div><!-- col-sm-6 col-md-3 finish -->

      <div class="com-sm-6 col-md-3"><!-- col-sm-6 col-md-3 begin -->

        <h4> Top products Categoies </h4>
        <ul><!-- ul begin -->
          <li><a href="#">Jacket</a></li>
          <li><a href="#">Accessories</a></li>
          <li><a href="#">Coats</a></li>
          <li><a href="#">Shoes</a></li>
          <li><a href="#">T-Sherts</a></li>

        </ul><!-- ul finish -->

         <hr class="hidden-md hidden-lg ">

      </div><!-- col-sm-6 col-md-3 finish -->

      <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 begin -->

        <h4> Find Us: </h4>

        <p><!-- p Begin -->
             <strong>P-Suli media inc.</strong>
             <br/>New Sulaymani
             <br/>Sulaymani
             <br/>+964-750-642-2861
             <br/>P-SuliBoutique@gmail.com
             <br/><strong>MrPasha</strong>

        </p><!-- p finish -->

      <a href="contact.php">Checkout our contact page</a>

         <hr class="hidden-md hidden-lg ">

      </div><!-- col-sm-6 col-md-3 finish -->

        <div class="col-sm-6 col-md-3">

          <h4>Get the news</h4>

          <p class="text-muted">
          dont miss latest update products
          </p>

          <form class="" action="get" method="post" ><!--form begin -->
            <div class="input-group"><!-- input-group begin -->

             <input  class="form-control" type="text" name="email" value="">
                  <span class="input-group-btn"><!-- input-group-btn begin -->
                      <input class="btn btn-default " type="submit" name="" value="subscribe">

                  </span><!-- input-group-btn finish -->


            </div><!-- input-group finish -->

          </form><!-- form finish -->
          <hr>
          <h4>Keep in touch</h4>
          <p class="social">
             <a href="#" class="fa fa-facebook"></a>
             <a href="#" class="fa fa-twitter"></a>
             <a href="#" class="fa fa-instagram"></a>
             <a href="#" class="fa fa-google-plus"></a>
             <a href="#" class="fa fa-envelope"></a>


           </p>
        </div>


    </div><!-- row finish -->
  </div><!-- containerR finish -->
</div><!-- FOOTER finish -->


<div id="copyright"><!-- copyright begin -->
  <div class="container"><!-- container begin -->
    <div class="col-md-6"><!-- col-md-6 begin -->

      <p class="pull-left">&copy; 2019 P-Suli Store</p>

    </div><!-- col-md-6 finish -->
    <div class="col-md-6"><!-- col-md-6 begin -->

      <p class="pull-right"> Theme by: <a href="#"> MrPasha</a> </p>

    </div><!-- col-md-6 finish -->

  </div><!-- container finish -->

</div><!-- copyright finish -->
