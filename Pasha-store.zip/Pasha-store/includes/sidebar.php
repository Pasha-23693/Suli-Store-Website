<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu begin -->
  <div class="panel-heading"><!-- panel-heading begin -->
    <h3 class="panel-title"> products Categoies</h3>

  </div><!-- panel-heading Finish -->

  <div class="panel-body"><!-- panel-body begin -->
    <ul class="nav nav-pills nav-stacked category-menu"><!-- nav nav-pills nav-stacked category-menu begin -->
<li> <a href="#">Jacket</a> </li>
<li> <a href="#">Accessories</a> </li>
<li> <a href="#">Shoes</a> </li>
<li> <a href="#">Coats</a> </li>
<li> <a href="#">T-shirt</a> </li>
    </ul><!-- nav nav-pills nav-stacked category-menu finish -->

  </div><!-- panel-body Finish -->
</div><!-- panel panel-default sidebar-menu Finish -->

<div class="panel panel-default sidebar-menu"><!-- panel panel-default sidebar-menu begin -->
  <div class="panel-heading"><!-- panel-heading begin -->
    <h3 class="panel-title">  Categoies</h3>

  </div><!-- panel-heading Finish -->

  <div class="panel-body"><!-- panel-body begin -->
    <ul class="nav nav-pills nav-stacked category-menu"><!-- nav nav-pills nav-stacked category-menu begin -->
<li> <a href="#">Men</a> </li>
<li> <a href="#">Women</a> </li>
<li> <a href="#">Kids</a> </li>
<li> <a href="#">Others</a> </li>

    </ul><!-- nav nav-pills nav-stacked category-menu finish -->

  </div><!-- panel-body Finish -->
</div><!-- panel panel-default sidebar-menu Finish -->
