<h1 align="center"> Edit Your Account</h1>

<form  action="" method="post" enctype="multipart/form-data"><!--- form begin -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer Name :</label>

    <input type="text" class="form-control" name="c_name"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer Email :</label>

    <input type="text" class="form-control" name="c_email"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer Country :</label>

    <input type="text" class="form-control" name="c_country"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer City :</label>

    <input type="text" class="form-control" name="c_city"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer Contact :</label>

    <input type="text" class="form-control" name="c_contact"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer Address :</label>

    <input type="text" class="form-control" name="c_address"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Costumer Image :</label>

    <input type="file" class="form-control" name="c_image"required>
    <img class="img-responsive" src="customer_images/MarkZuckerberg.jpg" alt="Costumer Image">

 </div><!--- form-group finish -->

 <div class="text-center"><!--- text-center begin -->

    <button name="update" class="btn btn-primary"><!---btn btn-primary begin -->

         <i class="fa fa-user-md"></i> Update Now
    </button><!--- btn btn-primary finish -->

 </div><!--- text-center finish -->

</form><!--- form finish -->
