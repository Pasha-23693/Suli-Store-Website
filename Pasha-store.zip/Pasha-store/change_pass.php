
<h1 align="center"> Change Your Password </h1>

<form  action="" method="post"><!--- form begin -->

 <div class="form-group"><!--- form-group begin -->
    <label> Your Old password :</label>

    <input type="text" class="form-control" name="old_pass"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Your New password :</label>

    <input type="text" class="form-control" name="new_pass"required>

 </div><!--- form-group finish -->

 <div class="form-group"><!--- form-group begin -->
    <label> Confirm Your New password : </label>

    <input type="text" class="form-control" name="new_pass_again"required>

 </div><!--- form-group finish -->

 <div class="text-center"><!--- text-center begin -->

    <button name="submit" type="submit" class="btn btn-primary"><!---btn btn-primary begin -->

         <i class="fa fa-user-md"></i> Update Now
    </button><!--- btn btn-primary finish -->

 </div><!--- text-center finish -->

</form><!--- form finish -->
