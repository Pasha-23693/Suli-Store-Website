<center><!-- center begin -->

<h1>My orders</h1>
<p class="lead">your order on one place</p>
<p class="text-muted"> if you have any questions, feel free to <a href="contact.php">contact us</a>. our customers service work <strong>24/7</strong>

</p>

<hr>
<div class="table-responsive"><!-- table-responsive begin -->
  <table class="table table-bordered table-hover"><!-- table table-bordered table-hover begin -->
    <thead><!-- thead begin -->
      <tr><!-- tr begin -->
        <th>ON:</th>
        <th>Due Amount:</th>
        <th>Invoice No:</th>
        <th>Qty:</th>
        <th>Size:</th>
        <th>Order Date:</th>
        <th>Paid / Unpaid:</th>
        <th>Status:</th>
      </tr><!-- tr finish -->
    </thead><!-- thead finish -->
    <tbody><!-- tbody begin -->
      <tr><!-- tr begin -->
        <th>#1</th>
        <td>$80</td>
        <td>233444</td>
        <td>2</td>
        <td>Small</td>
        <td>21/1/2019</td>
        <td>Unpaid:</td>
        <td>
          <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm paid</a>
        </td>

      </tr><!-- tr finish -->
      <tr><!-- tr begin -->
        <th>#1</th>
        <td>$80</td>
        <td>233444</td>
        <td>2</td>
        <td>Small</td>
        <td>21/1/2019</td>
        <td>Unpaid:</td>
        <td>
          <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm paid</a>
        </td>

      </tr><!-- tr finish -->
      <tr><!-- tr begin -->
        <th>#1</th>
        <td>$80</td>
        <td>233444</td>
        <td>2</td>
        <td>Small</td>
        <td>21/1/2019</td>
        <td>Unpaid:</td>
        <td>
          <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm paid</a>
        </td>

      </tr><!-- tr finish -->
    </tbody><!-- tbody finish -->

  </table><!-- table table-bordered table-hover finish -->
</div><!-- table-responsive finish -->


</center><!-- center finish -->
