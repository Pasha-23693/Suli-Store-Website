<center> <!-- Center begin -->

 <h1> Do You realy want to Delete your Account ?</h1>

 <form  action="" method="post"> <!-- form begin -->

      <input type="submit" name="Yes" value="yes,I want to Delete" class="btn btn-danger">

      <input type="submit" name="No" value="No,I Don't want to Delete" class="btn btn-primary">

 </form><!-- form finish -->

</center><!-- Center finish -->
