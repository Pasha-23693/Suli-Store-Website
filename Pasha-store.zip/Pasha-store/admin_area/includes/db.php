<?php
$con = mysqli_connect("localhost","root","","suli_store");


 ?>
