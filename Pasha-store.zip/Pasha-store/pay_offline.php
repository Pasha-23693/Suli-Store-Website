<center><!-- center begin -->

<h1>Pay offline Using Method</h1>
<p class="text-muted"> if you have any questions, feel free to <a href="contact.php">contact us</a>. our customers service work <strong>24/7</strong>

</p>

<hr>
<div class="table-responsive"><!-- table-responsive begin -->
  <table class="table table-bordered table-hover table-striped"><!-- table table-bordered table-hover begin -->
    <thead><!-- thead begin -->
      <tr><!-- tr begin -->

      <th> Bank Account details :</th>
      <th>Easy Paisa, UBL Omni, Mobi Cash details: </th>
      <th>Western Union details:</th>

      </tr><!-- tr finish -->
    </thead><!-- thead finish -->
    <tbody><!-- tbody begin -->

         <td> Bank Name : UBL | Account NO: 123-456-091 | Branch Name: Lahore |Branch code: 1456</td>
          <td> NIC #980-231-907 | Mobile No: 00975-765-234-1231 | Name: Mr pasha</td>
           <td>Real Name: Mr Sulaiman Asan | Mobile No: 00975-765-234-1231 | Country:USA | Name:Pasha |NIC #980-231-907 </td>


    </tbody><!-- tbody finish -->

  </table><!-- table table-bordered table-hover finish -->
</div><!-- table-responsive finish -->


</center><!-- center finish -->
